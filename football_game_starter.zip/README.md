
# Online Football Game Starter

This is a starter project for a browser-based 3D football game.

Features included:
- Three.js scene
- Pitch with markings
- Ball
- Two player capsules
- Basic movement
- Socket.IO multiplayer server scaffold

Run:
1. npm install in server folder
2. node server.js
3. Open client/index.html (or serve with a static server)

This is a foundation, not a full FIFA/FC clone.
