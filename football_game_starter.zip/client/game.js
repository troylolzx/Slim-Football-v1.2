
import * as THREE from 'https://unpkg.com/three@0.166.1/build/three.module.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);

const camera = new THREE.PerspectiveCamera(75,innerWidth/innerHeight,0.1,1000);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(innerWidth,innerHeight);
document.body.appendChild(renderer.domElement);

const light = new THREE.DirectionalLight(0xffffff,2);
light.position.set(20,30,10);
scene.add(light);

const pitch = new THREE.Mesh(
 new THREE.PlaneGeometry(80,50),
 new THREE.MeshStandardMaterial({color:0x2f8f2f})
);
pitch.rotation.x=-Math.PI/2;
scene.add(pitch);

const player = new THREE.Mesh(
 new THREE.CapsuleGeometry(0.6,1.2,4,8),
 new THREE.MeshStandardMaterial()
);
player.position.y=1;
scene.add(player);

const ball = new THREE.Mesh(
 new THREE.SphereGeometry(0.4,32,32),
 new THREE.MeshStandardMaterial({color:0xffffff})
);
ball.position.set(0,0.4,0);
scene.add(ball);

camera.position.set(0,10,12);

const keys={};
addEventListener("keydown",e=>keys[e.key]=true);
addEventListener("keyup",e=>keys[e.key]=false);

function animate(){
 requestAnimationFrame(animate);

 let speed=0.08;
 if(keys["Shift"]) speed=0.15;

 if(keys["w"]) player.position.z-=speed;
 if(keys["s"]) player.position.z+=speed;
 if(keys["a"]) player.position.x-=speed;
 if(keys["d"]) player.position.x+=speed;

 camera.position.x = player.position.x;
 camera.position.z = player.position.z + 12;
 camera.lookAt(player.position);

 renderer.render(scene,camera);
}
animate();
